package com.example.project_52


import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.JsonHttpResponseHandler
import cz.msebera.android.httpclient.Header
import org.json.JSONObject
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    // Base URL for the Pokémon API
    private val baseUrl = "https://pokeapi.co/api/v2/pokemon/"

    private lateinit var pokemonImage: ImageView
    private lateinit var nameText: TextView
    private lateinit var typeText: TextView
    private lateinit var nextButton: Button

    // single AsyncHttpClient instance
    private val client = AsyncHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Connect Kotlin variables to UI elements in XML
        pokemonImage = findViewById(R.id.PokeImage)
        nameText = findViewById(R.id.nameText)
        typeText = findViewById(R.id.typeText)
        nextButton = findViewById(R.id.nextButton)


        //Sets up the "Next Pokemon" button to fetch a random Pokémon when clicked
        nextButton.setOnClickListener {
            fetchRandomPokemon()
        }

        // initial load
        fetchRandomPokemon()
    }

    //This selects a Pokemon ID between 1 and 899
    private fun fetchRandomPokemon() {
        // Choose a random Pokémon id (1..898). Adjust upper bound as API grows.
        val id = Random.nextInt(1, 899)
        fetchPokemonById(id)
    }


    // This function takes the Pokemon id and makes the GET request
    // IT also gives details of the Pokemon such as name, type, and image
    private fun fetchPokemonById(id: Int) {
        val url = "$baseUrl$id/"

        // optional: show loading state
        nameText.text = "Loading..."
        typeText.text = ""

        // Makes the HTTP GET request
        client.get(url, object : JsonHttpResponseHandler() {
            override fun onSuccess(statusCode: Int, headers: Array<out Header>?, response: JSONObject) {
                try {
                    // Parse name field from the JSON response
                    val name = response.optString("name", "unknown").replaceFirstChar { it.uppercaseChar() }

                    // Extract the sprite image URL
                    val sprites = response.optJSONObject("sprites")
                    val spriteUrl = sprites?.optString("front_default") ?: ""

                    // Parse types array: [{"slot":1,"type":{"name":"grass","url":"..."}} , ...]
                    val typesArray = response.optJSONArray("types")
                    val typesList = mutableListOf<String>()
                    if (typesArray != null) {
                        for (i in 0 until typesArray.length()) {
                            val typeObj = typesArray.optJSONObject(i)?.optJSONObject("type")
                            val tname = typeObj?.optString("name")
                            if (!tname.isNullOrEmpty()) {
                                typesList.add(tname.replaceFirstChar { it.uppercaseChar() })
                            }
                        }
                    }
                    val typesString = if (typesList.isEmpty()) "Unknown" else typesList.joinToString(", ")

                    // Update UI on main thread (UI thread)
                    nameText.text = name
                    typeText.text = "Type: $typesString"

                    // Load image via Glide. If spriteUrl is empty, clear the image or load a placeholder.
                    if (spriteUrl.isNotEmpty()) {
                        Glide.with(this@MainActivity)
                            .load(spriteUrl)
                            .centerInside()
                            .into(pokemonImage)
                    } else {
                        // no sprite: clear / show placeholder
                        pokemonImage.setImageResource(android.R.color.transparent)
                    }

                } catch (e: Exception) {
                    e.printStackTrace()
                    nameText.text = "Parse error"
                    typeText.text = ""
                    pokemonImage.setImageResource(android.R.color.transparent)
                }
            }

            override fun onFailure(statusCode: Int, headers: Array<out Header>?, throwable: Throwable?, errorResponse: JSONObject?) {
                // Handle failure
                nameText.text = "Request failed (code $statusCode)"
                typeText.text = ""
                pokemonImage.setImageResource(android.R.color.transparent)
            }
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        // cancel requests when activity destroyed
        client.cancelAllRequests(true)
    }
}